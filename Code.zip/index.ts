const express = require("express");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const africastalking = require("africastalking");
const {
  createAuthenticatedClient,
} = require("@interledger/open-payments");

dotenv.config();

const app = express();

const port = process.env.PORT || 3000;

const WALLET_ADDRESS = process.env.OPEN_PAYMENTS_CLIENT_ADDRESS || "";
const ACCESS_TOKEN = process.env.OPEN_PAYMENTS_ACCESS_TOKEN || "";

if (!ACCESS_TOKEN) {
  console.error("Error: OPEN_PAYMENTS_ACCESS_TOKEN is not set in .env");
  process.exit(1);
}

// Africa's Talking setup
const at = africastalking({
  apiKey: process.env.AT_API_KEY || "",
  username: process.env.AT_USERNAME || "sandbox",
});
const sms = at.SMS;

async function sendSMS(to, message) {
  if (to.startsWith("0")) to = "+27" + to.slice(1);
  try {
    await sms.send({ to: [to], message });
    console.log(`SMS sent to ${to}: ${message}`);
  } catch (err) {
    console.error("SMS error:", err.message || err);
  }
}

let client;
let walletAddressDetails;

async function init() {
  client = await createAuthenticatedClient({
    walletAddressUrl: WALLET_ADDRESS,
    privateKey: process.env.OPEN_PAYMENTS_SECRET_KEY_PATH || "",
    keyId: process.env.OPEN_PAYMENTS_KEY_ID || "",
  });

  walletAddressDetails = await client.walletAddress.get({ url: WALLET_ADDRESS });

  console.log("Wallet details:", walletAddressDetails);
}
init().catch(console.error);

app.use(bodyParser.urlencoded({ extended: false }));

// Core function: send Interledger payment offline using stored token
async function sendInterledgerPayment(senderWalletAddress, recipientWalletAddress, amount) {
  // Create Quote
  const quote = await client.quote.create(
    {
      url: new URL(senderWalletAddress).origin,
      accessToken: ACCESS_TOKEN,
    },
    {
      method: "ilp",
      walletAddress: senderWalletAddress,
      receiver: recipientWalletAddress,
      receiveAmount: {
        value: amount,
        assetCode: walletAddressDetails.assetCode,
        assetScale: walletAddressDetails.assetScale,
      },
    }
  );

  // Create Outgoing Payment
  const payment = await client.outgoingPayment.create(
    {
      url: new URL(senderWalletAddress).origin,
      accessToken: ACCESS_TOKEN,
    },
    {
      walletAddress: senderWalletAddress,
      quoteId: quote.id,
    }
  );

  return payment;
}

// USSD POST endpoint
app.post("/ussd", async (req, res) => {
  const { sessionId, serviceCode, phoneNumber, text } = req.body;
  let response = "";

  const textArray = text.split("*");

  try {
    if (text === "") {
      response = `CON Welcome to MyApp
1. Send Payment
2. Check Balance
3. Exit`;
    } else if (text === "1") {
      response = `CON Enter recipient wallet address:`;
    } else if (textArray[0] === "1" && textArray.length === 2) {
      response = `CON Enter amount to send (in cents, e.g., 100 for R1.00):`;
    } else if (textArray[0] === "1" && textArray.length === 3) {
      const recipientWalletAddress = textArray[1];
      const amountStr = textArray[2];

      try {
        await sendInterledgerPayment(WALLET_ADDRESS, recipientWalletAddress, amountStr);

        response = `END Payment of ${amountStr} sent to ${recipientWalletAddress}`;
        await sendSMS(phoneNumber, `You sent ${amountStr} to ${recipientWalletAddress}`);
      } catch (err) {
        console.error("Payment error:", err);
        response = `END Payment failed: ${err.message || err.toString()}`;
      }
    } else if (text === "2") {
      // Dummy balance response example
      response = `END Your balance is R50.00`;
      await sendSMS(phoneNumber, `Balance check: R50.00`);
    } else if (text === "3") {
      response = `END Thank you for using MyApp. Goodbye!`;
    } else {
      response = `END Invalid input. Please try again.`;
    }
  } catch (err) {
    console.error("USSD handler error:", err);
    response = `END An error occurred: ${err.message || err.toString()}`;
  }

  res.set("Content-Type", "text/plain");
  res.send(response);
});

app.listen(port, () => {
  console.log(`USSD app running on http://localhost:${port}`);
});
