import express from 'express';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import africastalking from 'africastalking';
import { createAuthenticatedClient } from "@interledger/open-payments";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

const WALLET_ADDRESS = process.env.OPEN_PAYMENTS_CLIENT_ADDRESS;
const PRIVATE_KEY_PATH = process.env.OPEN_PAYMENTS_SECRET_KEY_PATH;
const KEY_ID = process.env.OPEN_PAYMENTS_KEY_ID;

let client: ReturnType<typeof createAuthenticatedClient>;
let walletAddressDetails: any;

async function init() {
  client = await createAuthenticatedClient({
    walletAddressUrl: WALLET_ADDRESS,
    privateKey: PRIVATE_KEY_PATH,
    keyId: KEY_ID,
  });

  walletAddressDetails = await client.walletAddress.get({ url: WALLET_ADDRESS });
}
init();

// Africa's Talking setup
const at = africastalking({
  apiKey: process.env.AT_API_KEY,
  username: process.env.AT_USERNAME,
});

const sms = at.SMS;

const sendSMS = async (to: string, message: string) => {
  if (to.startsWith('0')) to = '+27' + to.slice(1);
  try {
    await sms.send({ to: [to], message });
    console.log('SMS sent:', to);
  } catch (err: any) {
    console.error('SMS error:', err.message);
  }
};

app.use(bodyParser.urlencoded({ extended: false }));

app.post('/ussd', async (req, res) => {
  const { sessionId, serviceCode, phoneNumber, text } = req.body;
  let response = '';
  const textArray = text.split('*');

  try {
    if (text === '') {
      response = `CON Welcome to MyApp
1. Sign_Up
2. Check Balance
3. Buy Airtime
4. Send Money
5. Sign_out
6. Transactions`;
    }
    else if (text === '1') {
      response = `CON Enter your full name:`;
    }
    else if (textArray[0] === '1' && textArray.length === 2) {
      response = `CON Enter your ID number:`;
    }
    else if (textArray[0] === '1' && textArray.length === 3) {
      response = `CON Enter your phone number:`;
    }
    else if (textArray[0] === '1' && textArray.length === 4) {
      const [_, name, id, userPhone] = textArray;
      response = `END Thank you ${name}, you have successfully signed up!`;
      await sendSMS(userPhone, `Hi ${name}, your sign-up was successful!`);
    }
    else if (text === '2') {
      response = `END Your balance is R50`;
      await sendSMS(phoneNumber, `Balance Check: Your current balance is R50`);
    }
    else if (text === '3') {
      response = `CON Enter amount to buy:`;
    }
    else if (textArray[0] === '3' && textArray.length === 2) {
      const amount = textArray[1];
      response = `END You have bought R${amount} airtime`;
      await sendSMS(phoneNumber, `Airtime Purchase: You bought R${amount} airtime`);
    }
    // SEND MONEY FLOW - Here is the new Interledger payment code
    else if (text === '4') {
      response = `CON Enter recipient wallet address:`;  // Changed from phone number to wallet address (could customize)
    }
    else if (textArray[0] === '4' && textArray.length === 2) {
      response = `CON Enter amount to send to ${textArray[1]}:`;
    }
    else if (textArray[0] === '4' && textArray.length === 3) {
      const recipientWalletAddress = textArray[1];
      const amountStr = textArray[2];

      // Create quote and outgoing payment
      try {
        // Create quote
        const quote = await client.quote.create(
          {
            url: new URL(WALLET_ADDRESS).origin,
            accessToken: process.env.OPEN_PAYMENTS_ACCESS_TOKEN, // You need to store and reuse your token here
          },
          {
            method: "ilp",
            walletAddress: WALLET_ADDRESS,
            receiver: recipientWalletAddress,
            sendAmount: {
              value: amountStr,
              assetCode: walletAddressDetails.assetCode,
              assetScale: walletAddressDetails.assetScale,
            },
          }
        );

        // Create outgoing payment
        const payment = await client.outgoingPayment.create(
          {
            url: new URL(WALLET_ADDRESS).origin,
            accessToken: process.env.OPEN_PAYMENTS_ACCESS_TOKEN, // Same token as above
          },
          {
            walletAddress: WALLET_ADDRESS,
            quoteId: quote.id,
          }
        );

        response = `END You have sent R${amountStr} to ${recipientWalletAddress}`;
        await sendSMS(phoneNumber, `You sent R${amountStr} to ${recipientWalletAddress}`);

      } catch (error: any) {
        console.error("Payment error:", error);
        response = `END Payment failed: ${error.message || error.toString()}`;
      }
    }
    else if (text === '5') {
      response = `END You have been signed out successfully.`;
      await sendSMS(phoneNumber, `You have signed out of your account.`);
    }
    else if (text === '6') {
      response = `END Last 3 transactions:
- R20 to 0781234567
- R10 airtime
- R100 received`;
      await sendSMS(phoneNumber, `Transactions: R20 sent, R10 airtime, R100 received`);
    }
    else {
      response = `END Invalid option. Please try again.`;
    }
  } catch (err: any) {
    console.error("USSD handler error:", err);
    response = `END An error occurred: ${err.message || err.toString()}`;
  }

  res.set('Content-Type', 'text/plain');
  res.send(response);
});

app.listen(port, () => {
  console.log(`USSD app running on http://localhost:${port}`);
});
